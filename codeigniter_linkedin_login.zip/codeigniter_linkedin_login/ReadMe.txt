Author : CodexWorld
Author URI : http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/codeigniter-linkedin-login/

Installation Instructions:
==================================================
1. Import the "SQL/users.sql" file into the database of your CodeIgniter application.
2. Move all files to the same directory of your CodeIgniter application.
3. Open the "application/config/linkedin.php" file and specify the Client ID (linkedin_api_key) and Client Secret (linkedin_api_secret) according to your LinkedIn App credentials.
4. Open the URL (https://www.example.com/user_authentication/) on the browser and test the login with LinkedIn in CodeIgniter.

============ May I Help You ===========
If you have any query about this script, send us by posting a comment here - http://www.codexworld.com/codeigniter-linkedin-login/#respond.